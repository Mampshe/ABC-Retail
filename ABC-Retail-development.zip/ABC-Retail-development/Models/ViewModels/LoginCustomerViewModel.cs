﻿using System.ComponentModel.DataAnnotations;

namespace ABC_Retail.Models.ViewModels
{
    public class LoginCustomerViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

    }
}
